#ifndef YELLOW_BATTLE_H
#define YELLOW_BATTLE_H
#pragma once
#include <stdint.h>
#include <stdbool.h>

typedef enum {YK_EEVEE=0,YK_PIDGEY=1,YK_RATTATA=2,YK_PIKACHU=3} YSpecies;
typedef enum {
    YM_THUNDERSHOCK=0,YM_GROWL,YM_TAIL_WHIP,YM_TACKLE,
    YM_GUST,YM_QUICK_ATTACK,YM_SAND_ATTACK,YM_NONE=255
} YMoveId;
typedef enum {YT_NORMAL=0,YT_FLYING=1,YT_ELECTRIC=2} YType;
typedef struct {
    const char* name;
    uint8_t hp,attack,defense,speed,special,exp_yield;
    uint8_t type1,type2;
    uint8_t growth; /* 0=medium-fast, 1=medium-slow */
} YSpeciesInfo;
typedef struct {
    const char* name;
    uint8_t power,accuracy,pp,type,special;
} YMoveInfo;
typedef struct {
    uint8_t hp,attack,defense,speed,special;
} YBattleStats;
typedef struct {
    uint8_t damage,hit;
} YDamage;

const YSpeciesInfo* y_species_info(uint8_t species);
const YMoveInfo* y_move_info(uint8_t move);
YBattleStats y_calc_stats(uint8_t species,uint8_t level);
uint32_t y_exp_threshold(uint8_t species,uint8_t level);
uint16_t y_exp_award(uint8_t species,uint8_t level,bool trainer);
uint8_t y_max_pp(uint8_t move);
uint8_t y_player_move(uint8_t level,uint8_t slot);
uint8_t y_player_move_count(uint8_t level);
YDamage y_calc_damage(uint8_t source,uint8_t source_level,
                      uint8_t target,uint8_t target_level,
                      uint8_t move,int8_t attack_stage,int8_t defense_stage,
                      uint8_t hit_roll,uint8_t rand_roll);

#endif
