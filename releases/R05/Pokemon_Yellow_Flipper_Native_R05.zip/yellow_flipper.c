#include <furi.h>
#include <gui/gui.h>
#include <storage/storage.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include "yellow_core.h"
#include "yellow_assets.h"

#define SAVE_PATH "/ext/apps_data/yellow_native/save_v05.dat"
#define SAVE_DIR "/ext/apps_data/yellow_native"

typedef struct {
    YellowGame g;
    FuriMessageQueue* queue;
    FuriMutex* lock;
    ViewPort* viewport;
    Gui* gui;
} YellowApp;

static int clamp(int x,int lo,int hi) {
    if(x<lo)return lo;
    if(x>hi)return hi;
    return x;
}
static const uint8_t* actor_pixels(uint8_t type) {
    switch(type) {
    case YActorOak:return ysprite_oak;
    case YActorGirl:return ysprite_little_girl;
    case YActorFisher:return ysprite_fisher;
    case YActorBlue:return ysprite_blue;
    case YActorPikachu:return ysprite_pikachu;
    case YActorMom:return ysprite_mom;
    case YActorDaisy:return ysprite_daisy;
    case YActorPokedex:return ysprite_pokedex;
    case YActorPokeBall:return ysprite_poke_ball;
    case YActorScientist:return ysprite_scientist;
    case YActorYoungster:return ysprite_youngster;
    case YActorGambler:return ysprite_gambler;
    case YActorNurse:return ysprite_nurse;
    case YActorGentleman:return ysprite_gentleman;
    case YActorCooltrainer:return ysprite_cooltrainer_m;
    case YActorReceptionist:return ysprite_link_receptionist;
    case YActorChansey:return ysprite_chansey;
    case YActorRed:default:return ysprite_red;
    }
}
static void actor(Canvas* c,int x,int y,uint8_t type,int facing) {
    if(x<=-16||x>=128||y<=-16||y>=64)return;
    const uint8_t* sheet=actor_pixels(type);
    // Original 16x96 2-bit sprite is converted to six 16x16 1-bit frames.
    // The first 2 frames face down, next 2 face up, last 2 face sideways.
    int frame=(type==YActorPokedex||type==YActorPokeBall||type==YActorMom||type==YActorNurse||type==YActorChansey)?0:
        (facing==YUp)?2:(facing==YLeft||facing==YRight)?4:0;
    canvas_set_bitmap_mode(c,true);
    canvas_draw_xbm(c,x,y,16,16,sheet+frame*32);
}
static void render_world(Canvas* c,const YellowGame* g) {
    const YellowLevelAsset* level=&yellow_levels[g->map];
    const int world_w=level->w*32,world_h=level->h*32;
    const int cam_x=clamp(g->x*16-56,0,world_w-128);
    const int cam_y=clamp(g->y*16-24,0,world_h-64);
    const int first_col=cam_x/8,first_row=cam_y/8;
    canvas_set_color(c,ColorBlack);
    // World is displayed at original pixel resolution: no shrink/stretch.
    canvas_set_bitmap_mode(c,false);
    for(int row=first_row;row<=first_row+8&&row<world_h/8;row++) {
        for(int col=first_col;col<=first_col+16&&col<world_w/8;col++) {
            int x=col*8-cam_x,y=row*8-cam_y;
            uint8_t tile=yellow_tile_id(g->map,col,row);
            if(tile<level->tiles_count) {
                canvas_draw_xbm(c,x,y,8,8,level->tiles+tile*8);
            }
        }
    }
    for(uint8_t i=0;i<yellow_npc_count;i++) {
        const YellowNpc* n=&yellow_npcs[i];
        if(yellow_npc_visible(g,n))
            actor(c,n->x*16-cam_x,n->y*16-cam_y,n->type,YDown);
    }
    if(g->story==YStoryPikachuFollows && g->has_pikachu &&
       g->follower_valid && g->follower_map==g->map) {
        actor(c,g->follower_x*16-cam_x,g->follower_y*16-cam_y,YActorPikachu,g->facing);
    }
    actor(c,g->x*16-cam_x,g->y*16-cam_y,YActorRed,g->facing);
}
static void render_dialog(Canvas* c,const YellowGame* g) {
    canvas_set_color(c,ColorWhite);
    canvas_draw_box(c,0,34,128,30);
    canvas_set_color(c,ColorBlack);
    canvas_draw_frame(c,0,34,128,30);
    canvas_set_font(c,FontSecondary);
    const char* const* lines=&g->dialog_lines[2*g->dialog_page];
    canvas_draw_str(c,4,45,lines[0]);
    canvas_draw_str(c,4,56,lines[1]);
    canvas_draw_str(c,120,62,">");
}
static void render_menu(Canvas* c,const YellowGame* g) {
    static const char* const items[]={"PARTY","BAG","SAVE","EXIT"};
    canvas_set_font(c,FontSecondary);
    canvas_draw_str(c,2,10,"POKEMON YELLOW [PORT]");
    for(int i=0;i<4;i++){
        int y=23+i*12;
        if(g->selected==i)canvas_draw_str(c,6,y,">");
        canvas_draw_str(c,19,y,items[i]);
    }
    if(g->request_save)canvas_draw_str(c,78,61,"SAVING");
    else if(g->message_saved)canvas_draw_str(c,84,61,"SAVED");
}
static void render_info(Canvas* c,const YellowGame* g) {
    canvas_set_font(c,FontSecondary);
    char health[24];
    if(g->screen==YScreenParty) {
        canvas_draw_str(c,3,11,"PARTY");
        canvas_draw_frame(c,1,15,126,39);
        if(g->has_pikachu) {
            snprintf(health,sizeof(health),"PIKACHU Lv%u",(unsigned)g->pika_level);
            canvas_draw_str(c,6,24,health);
            snprintf(health,sizeof(health),"HP %u/%u",(unsigned)g->hp,(unsigned)yellow_player_max_hp(g));
            canvas_draw_str(c,6,35,health);
            snprintf(health,sizeof(health),"EXP %lu",(unsigned long)g->experience);
            canvas_draw_str(c,6,47,health);
            canvas_draw_xbm(c,103,25,16,16,ysprite_pikachu);
        } else canvas_draw_str(c,5,28,"NO POKEMON YET");
    } else {
        canvas_draw_str(c,3,11,"BAG");
        canvas_draw_frame(c,1,15,126,39);
        canvas_draw_str(c,6,30,"ITEMS COMING SOON");
    }
    canvas_draw_str(c,3,62,"BACK: RETURN");
}
static void render_oak_capture(Canvas* c) {
    canvas_set_font(c,FontSecondary);
    canvas_draw_str(c,2,10,"WILD PIKACHU!  Lv5");
    canvas_set_bitmap_mode(c,false);
    canvas_draw_xbm(c,87,14,40,40,ypokemon_pikachu_front);
    canvas_set_bitmap_mode(c,true);
    canvas_draw_str(c,3,34,"OAK THROWS");
    canvas_draw_str(c,3,46,"A POKE BALL!");
    canvas_draw_str(c,3,62,"OK: CONTINUE");
}
static void render_battle(Canvas* c,const YellowGame* g) {
    char hp[25];
    canvas_set_font(c,FontSecondary);
    const char* name=g->foe_kind==1?"PIDGEY":g->foe_kind==2?"RATTATA":"EEVEE";
    snprintf(hp,sizeof(hp),"%s LV%u",name,(unsigned)g->foe_level);
    canvas_draw_str(c,1,9,hp);
    canvas_draw_frame(c,1,12,68,5);
    if(g->foe_hp&&g->foe_max_hp)
        canvas_draw_box(c,3,14,g->foe_hp*64/g->foe_max_hp,1);
    canvas_set_bitmap_mode(c,false);
    const uint8_t* pic=g->foe_kind==1?ypokemon_pidgey_front:
                       g->foe_kind==2?ypokemon_rattata_front:ypokemon_eevee_front;
    canvas_draw_xbm(c,86,0,40,40,pic);
    canvas_draw_xbm(c,4,32,32,32,ypokemon_pikachu_back);
    canvas_set_bitmap_mode(c,true);
    snprintf(hp,sizeof(hp),"PIKACHU LV%u",(unsigned)g->pika_level);
    canvas_draw_str(c,49,45,hp);
    snprintf(hp,sizeof(hp),"HP %u/%u",(unsigned)g->hp,(unsigned)yellow_player_max_hp(g));
    canvas_draw_str(c,49,57,hp);
    canvas_draw_str(c,87,63,"OK:MOVE");
}
static void render_fight_menu(Canvas* c,const YellowGame* g) {
    canvas_set_font(c,FontSecondary);
    canvas_draw_str(c,2,9,"PIKACHU - SELECT MOVE");
    canvas_draw_line(c,0,12,127,12);
    uint8_t total=y_player_move_count(g->pika_level);
    for(uint8_t i=0;i<=total;i++) {
        int y=23+(int)i*12;
        if(i==g->selected)canvas_draw_str(c,1,y,">");
        if(i==total) {
            canvas_draw_str(c,11,y,g->foe_kind?"RUN":"RUN (NO)");
        } else {
            uint8_t move=y_player_move(g->pika_level,i);
            const YMoveInfo* info=y_move_info(move);
            if(info) {
                canvas_draw_str(c,11,y,info->name);
                char pp[8];
                snprintf(pp,sizeof(pp),"%u",(unsigned)g->pika_pp[i]);
                canvas_draw_str(c,113,y,pp);
            }
        }
    }
}
static void draw_cb(Canvas* c,void* context) {
    YellowApp* a=context;
    if(furi_mutex_acquire(a->lock,FuriWaitForever)!=FuriStatusOk)return;
    canvas_clear(c);
    canvas_set_color(c,ColorBlack);
    switch(a->g.screen){
    case YScreenWorld:render_world(c,&a->g);break;
    case YScreenDialog:render_world(c,&a->g);render_dialog(c,&a->g);break;
    case YScreenMenu:render_menu(c,&a->g);break;
    case YScreenParty:case YScreenBag:render_info(c,&a->g);break;
    case YScreenOakEncounter:render_oak_capture(c);break;
    case YScreenRivalBattle:render_battle(c,&a->g);break;
    case YScreenFightMenu:render_fight_menu(c,&a->g);break;
    }
    furi_mutex_release(a->lock);
}
static void input_cb(InputEvent* event,void* context) {
    YellowApp* a=context;
    if(event->type==InputTypeShort||event->type==InputTypeRepeat)
        (void)furi_message_queue_put(a->queue,event,0);
}
static bool save_game(Storage* storage,YellowGame* g) {
    YellowSave s;
    yellow_save_create(g,&s);
    storage_common_mkdir(storage,SAVE_DIR);
    File* f=storage_file_alloc(storage);
    bool ok=storage_file_open(f,SAVE_PATH,FSAM_WRITE,FSOM_CREATE_ALWAYS);
    if(ok)ok=storage_file_write(f,&s,sizeof(s))==sizeof(s);
    if(storage_file_is_open(f))storage_file_close(f);
    storage_file_free(f);
    return ok;
}
static bool load_game(Storage* storage,YellowGame* g) {
    YellowSave s;
    File* f=storage_file_alloc(storage);
    bool ok=storage_file_open(f,SAVE_PATH,FSAM_READ,FSOM_OPEN_EXISTING);
    if(ok)ok=storage_file_read(f,&s,sizeof(s))==sizeof(s);
    if(storage_file_is_open(f))storage_file_close(f);
    storage_file_free(f);
    return ok&&yellow_save_load(g,&s);
}

int32_t yellow_native_app(void* context) {
    UNUSED(context);
    YellowApp* a=malloc(sizeof(YellowApp));
    if(!a)return -1;
    yellow_init(&a->g);
    a->queue=furi_message_queue_alloc(12,sizeof(InputEvent));
    a->lock=furi_mutex_alloc(FuriMutexTypeNormal);
    a->viewport=view_port_alloc();
    a->gui=furi_record_open(RECORD_GUI);
    Storage* storage=furi_record_open(RECORD_STORAGE);
    (void)load_game(storage,&a->g);
    view_port_draw_callback_set(a->viewport,draw_cb,a);
    view_port_input_callback_set(a->viewport,input_cb,a);
    gui_add_view_port(a->gui,a->viewport,GuiLayerFullscreen);
    InputEvent event;
    while(a->g.running){
        if(furi_message_queue_get(a->queue,&event,FuriWaitForever)==FuriStatusOk){
            YellowKey key;
            if(event.key==InputKeyUp)key=YUp;
            else if(event.key==InputKeyDown)key=YDown;
            else if(event.key==InputKeyLeft)key=YLeft;
            else if(event.key==InputKeyRight)key=YRight;
            else if(event.key==InputKeyOk)key=YOk;
            else if(event.key==InputKeyBack)key=YBack;
            else continue;
            furi_mutex_acquire(a->lock,FuriWaitForever);
            yellow_input(&a->g,key);
            if(a->g.request_save){
                a->g.message_saved=save_game(storage,&a->g);
                a->g.request_save=false;
            }
            bool running=a->g.running;
            furi_mutex_release(a->lock);
            if(running)view_port_update(a->viewport);
        }
    }
    gui_remove_view_port(a->gui,a->viewport);
    view_port_free(a->viewport);
    furi_record_close(RECORD_STORAGE);
    furi_record_close(RECORD_GUI);
    furi_mutex_free(a->lock);
    furi_message_queue_free(a->queue);
    free(a);
    return 0;
}
