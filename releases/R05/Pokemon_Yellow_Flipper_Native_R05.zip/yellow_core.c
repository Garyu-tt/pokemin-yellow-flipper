#include "yellow_core.h"
#include "yellow_assets.h"
#include <string.h>

/*
 * Native game logic; original Gen 1 maps/tiles/overworld actors originate
 * from pret/pokeyellow. This is a limited adaptation of the opening sequence,
 * NOT a byte-identical implementation of Pokemon Yellow's battle formula,
 * movement scripts, or complete event engine.
 */

enum {
    TalkOak,TalkGirl,TalkFisher,TalkMom,TalkDaisy,TalkRival,
    TalkLabOak,TalkLabGirl,TalkScientist,TalkTownSign,TalkLabSign,
    TalkHomeSign,TalkRivalSign,TalkMap,TalkTV,TalkExit,TalkRouteYoungster,TalkRouteSign,TalkViridianResident,TalkViridianSign,TalkViridianCenter,TalkReception
};
const YellowNpc yellow_npcs[]={
    {YMapPallet,10,4,YActorOak,TalkOak},
    {YMapPallet,3,8,YActorGirl,TalkGirl},
    {YMapPallet,11,14,YActorFisher,TalkFisher},
    {YMapRedsHouse,5,4,YActorMom,TalkMom},
    {YMapBluesHouse,2,3,YActorDaisy,TalkDaisy},
    {YMapBluesHouse,6,4,YActorDaisy,TalkDaisy},
    {YMapBluesHouse,3,3,YActorPokedex,TalkMap},
    {YMapOaksLab,4,3,YActorBlue,TalkRival},
    {YMapOaksLab,7,3,YActorPokeBall,TalkLabOak},
    {YMapOaksLab,5,2,YActorOak,TalkLabOak},
    {YMapOaksLab,5,10,YActorOak,TalkLabOak},
    {YMapOaksLab,1,9,YActorGirl,TalkLabGirl},
    {YMapOaksLab,2,10,YActorScientist,TalkScientist},
    {YMapOaksLab,8,10,YActorScientist,TalkScientist},
    /* route/city object event coordinates copied from original object files */
    {YMapRoute1,5,24,YActorYoungster,TalkRouteYoungster},
    {YMapRoute1,15,13,YActorYoungster,TalkRouteYoungster},
    {YMapViridian,13,20,YActorYoungster,TalkViridianResident},
    {YMapViridian,30,8,YActorGambler,TalkViridianResident},
    {YMapViridian,30,25,YActorYoungster,TalkViridianResident},
    {YMapViridian,17,9,YActorGirl,TalkViridianResident},
    {YMapViridian,18,9,YActorGambler,TalkViridianResident},
    {YMapViridian,6,23,YActorFisher,TalkViridianResident},
    {YMapViridian,17,5,YActorGambler,TalkViridianResident},
    {YMapViridianCenter,3,1,YActorNurse,TalkViridianCenter},
    {YMapViridianCenter,10,5,YActorGentleman,TalkViridianResident},
    {YMapViridianCenter,4,3,YActorCooltrainer,TalkViridianResident},
    {YMapViridianCenter,11,2,YActorReceptionist,TalkReception},
    {YMapViridianCenter,4,1,YActorChansey,TalkViridianResident},
};
const uint8_t yellow_npc_count=(uint8_t)(sizeof(yellow_npcs)/sizeof(yellow_npcs[0]));

static const char* const intro[]={
    "PALLET TOWN","YOUR JOURNEY BEGINS",
    "ORIGINAL MAP ART","NATIVE 128X64 VIEW",
    "D-PAD: MOVE","OK: INTERACT"
};
static const char* const oak_regular[]={"OAK: Be careful!","Tall grass is risky."};
static const char* const girl[]={
    "I'm raising","POKEMON too!",
    "When they get","strong, they can",
    "protect me!",""
};
static const char* const fisher[]={
    "Technology is","incredible!",
    "Items and POKEMON","can be stored",
    "as data in a PC.",""
};
static const char* const mom[]={"MOM: Travel safe!","Come back sometime."};
static const char* const daisy[]={"DAISY: Hi!","Nice to see you."};
static const char* const rival[]={"RIVAL: I'll show","you how it's done."};
static const char* const lab_oak[]={"OAK: Choose wisely.","(more events TODO)"};
static const char* const lab_girl[]={"OAK'S LAB ASSISTANT","HELLO!"};
static const char* const scientist[]={"RESEARCHER:","POKEMON ARE AMAZING!"};
static const char* const town_sign[]={"PALLET TOWN","Shades of your","journey await!",""};
static const char* const lab_sign[]={"OAK POKEMON","RESEARCH LAB"};
static const char* const home_sign[]={"PLAYER'S HOUSE",""};
static const char* const rival_sign[]={"RIVAL'S HOUSE",""};
static const char* const townmap[]={"KANTO TOWN MAP","(not ported yet)"};
static const char* const tv[]={"A TV SET.",""};
static const char* const exit_text[]={"ROUTE CONNECTION","(not ported yet)"};
static const char* const oak_warning[]={
    "OAK: HEY! WAIT!","DON'T GO OUT!",
    "WILD POKEMON LIVE","IN TALL GRASS!",
    "LET ME HELP YOU.",""
};
static const char* const capture_text[]={
    "OAK: PHEW!","THAT WAS CLOSE!",
    "OAK CAUGHT A","WILD PIKACHU.",
    "COME WITH ME TO","MY LAB!"
};
static const char* const lab_intro[]={
    "IN OAK'S LAB...","",
    "OAK: CHOOSE A","POKEMON.",
    "RIVAL: HMPH!","I WANT THAT BALL!"
};
static const char* const starter_text[]={
    "RIVAL GRABS","THE EEVEE BALL!",
    "OAK: TAKE THIS","PIKACHU INSTEAD.",
    "PIKACHU JOINED","YOUR PARTY!"
};
static const char* const challenge_text[]={
    "RIVAL: LET'S SEE","WHO IS STRONGER!",
    "PIKACHU VS EEVEE","LEVEL 5"
};
static const char* const victory_text[]={"RIVAL: HMPH!","I'LL WIN NEXT TIME!"};
static const char* const defeat_text[]={"PIKACHU FAINTED!","OAK HEALED IT."};
static const char* const follower_text[]={
    "PIKACHU DOESN'T","LIKE ITS POKE BALL.",
    "IT WILL FOLLOW","YOU EVERYWHERE!"
};
static const char* const pika_happy[]={"PIKA PIKA!","IT LOOKS HAPPY."};
static const char* const pika_normal[]={"PIKA?","IT LOOKS AT YOU."};
static const char* const early_lab[]={"OAK ISN'T HERE.","COME BACK LATER!"};
static const char* const route_youngster[]={"ROUTE 1","TALL GRASS AHEAD!"};
static const char* const route_sign[]={"ROUTE 1","PALLET - VIRIDIAN"};
static const char* const viridian_resident[]={"VIRIDIAN CITY","HELLO TRAINER!"};
static const char* const viridian_sign[]={"VIRIDIAN CITY","THE ETERNALLY GREEN"};
static const char* const viridian_center[]={"WELCOME TO OUR","POKEMON CENTER!",
    "YOUR POKEMON","IS FULLY HEALED!"};
static const char* const reception[]={"LINK CABLE ROOM","NOT PORTED YET"};
static const char* const wild_victory[]={"WILD POKEMON","FAINTED!"};
static const char* const wild_flee[]={"GOT AWAY","SAFELY!"};
static const char* const wild_defeat[]={"PIKACHU FAINTED!","BACK TO MOM!"};
static const uint8_t encounter_weights[10]={51,51,39,25,25,25,13,13,11,3};
static const uint8_t route1_levels[10]={3,4,2,3,2,3,5,4,6,7};
static const uint8_t route1_kinds[10]={1,1,2,2,1,1,1,2,1,1};

static const char* const empty_ball[]={"EMPTY POKE BALL","RIVAL TOOK EEVEE"};

typedef struct {const char* const* lines;uint8_t pages;} DialogDef;
static const DialogDef dialogs[]={
    {oak_regular,1},{girl,3},{fisher,3},{mom,1},{daisy,1},
    {rival,1},{lab_oak,1},{lab_girl,1},{scientist,1},
    {town_sign,2},{lab_sign,1},{home_sign,1},{rival_sign,1},
    {townmap,1},{tv,1},{exit_text,1},
    {route_youngster,1},{route_sign,1},{viridian_resident,1},
    {viridian_sign,1},{viridian_center,2},{reception,1}
};

static void open_dialog(YellowGame* g,const char* const* lines,uint8_t pages,YellowPending pending) {
    g->dialog_lines=lines;g->dialog_count=pages;
    g->dialog_page=0;g->pending=pending;g->screen=YScreenDialog;
}
static void dialog_id(YellowGame* g,uint8_t id) {
    if(id>=sizeof(dialogs)/sizeof(dialogs[0]))return;
    open_dialog(g,dialogs[id].lines,dialogs[id].pages,YPendingNone);
}

static uint32_t next_rng(YellowGame* g) {
    uint32_t x=g->rng?g->rng:0x96C08u;
    x^=x<<13;x^=x>>17;x^=x<<5;
    return g->rng=x?x:0xA53DCu;
}
int yellow_map_w(uint8_t map) {
    return map<YELLOW_MAP_COUNT?yellow_levels[map].w*2:0;
}
int yellow_map_h(uint8_t map) {
    return map<YELLOW_MAP_COUNT?yellow_levels[map].h*2:0;
}
uint8_t yellow_tile_id(uint8_t map,int x,int y) {
    if(map>=YELLOW_MAP_COUNT)return 0xff;
    const YellowLevelAsset* a=&yellow_levels[map];
    if(x<0||y<0||x>=a->w*4||y>=a->h*4)return 0xff;
    uint8_t block=a->map[(y/4)*a->w+x/4];
    if(block>=a->blocks_count)return 0xff;
    uint8_t id=a->blocks[block*16+(y%4)*4+(x%4)];
    return id<a->tiles_count?id:0xff;
}
bool yellow_npc_visible(const YellowGame* g,const YellowNpc* n) {
    if(g->map!=n->map)return false;
    if(n->map==YMapPallet&&n->type==YActorOak)
        return g->story==YStoryBeforeOak; /* Oak leaves Pallet in intro */
    if(n->map==YMapOaksLab) {
        if(n->type==YActorOak&&n->y==10)
            return g->story==YStoryOakEncounter;
        if(n->type==YActorOak&&n->y==2)
            return g->story>=YStoryChooseStarter;
        if(n->type==YActorPokeBall)
            return g->story<YStoryRivalBattle;
    }
    return true;
}
static bool npc_at(const YellowGame* g,int x,int y) {
    for(uint8_t i=0;i<yellow_npc_count;i++)
        if(yellow_npcs[i].x==x&&yellow_npcs[i].y==y&&
           yellow_npc_visible(g,&yellow_npcs[i]))return true;
    return false;
}
static bool base_passable(uint8_t map,int x,int y) {
    if(map>=YELLOW_MAP_COUNT||x<0||y<0||x>=yellow_map_w(map)||y>=yellow_map_h(map))
        return false;
    /* Gen1 collision checks the bottom-left 8x8 tile of each 16x16 step. */
    uint8_t tile=yellow_tile_id(map,x*2,y*2+1);
    return tile<96&&yellow_levels[map].collision[tile]!=0;
}
static bool destination(uint8_t map,int x,int y,uint8_t* target,uint8_t* dx,uint8_t* dy) {
    if(map==YMapPallet) {
        if(x==5&&y==5){*target=YMapRedsHouse;*dx=2;*dy=6;return true;}
        if(x==13&&y==5){*target=YMapBluesHouse;*dx=2;*dy=6;return true;}
        if(x==12&&y==11){*target=YMapOaksLab;*dx=4;*dy=10;return true;}
    } else if(map==YMapRedsHouse) {
        if((x==2||x==3)&&y==7){*target=YMapPallet;*dx=5;*dy=6;return true;}
    } else if(map==YMapBluesHouse) {
        if((x==2||x==3)&&y==7){*target=YMapPallet;*dx=13;*dy=6;return true;}
    } else if(map==YMapOaksLab) {
        if((x==4||x==5)&&y==11){*target=YMapPallet;*dx=12;*dy=12;return true;}
    } else if(map==YMapViridian) {
        if(x==23&&y==25){*target=YMapViridianCenter;*dx=3;*dy=6;return true;}
    } else if(map==YMapViridianCenter) {
        if((x==3||x==4)&&y==7){*target=YMapViridian;*dx=23;*dy=26;return true;}
    }
    return false;
}
bool yellow_walkable(const YellowGame* g,int x,int y) {
    uint8_t target,dx,dy;
    if(destination(g->map,x,y,&target,&dx,&dy))return true;
    return base_passable(g->map,x,y)&&!npc_at(g,x,y);
}
static void set_follower_near(YellowGame* g) {
    g->follower_valid=0;
    if(g->story!=YStoryPikachuFollows||!g->has_pikachu)return;
    static const int8_t delta[][2]={{0,1},{0,-1},{-1,0},{1,0}};
    for(int i=0;i<4;i++) {
        int x=g->x+delta[i][0],y=g->y+delta[i][1];
        if(yellow_walkable(g,x,y)) {
            g->follower_map=g->map;g->follower_x=(uint8_t)x;
            g->follower_y=(uint8_t)y;g->follower_valid=1;return;
        }
    }
}
static void set_map(YellowGame* g,uint8_t map,uint8_t x,uint8_t y) {
    g->map=map;g->x=(int8_t)x;g->y=(int8_t)y;
    set_follower_near(g);
}
void yellow_init(YellowGame* g) {
    memset(g,0,sizeof(*g));g->map=YMapRedsHouse;
    g->x=3;g->y=6;g->facing=YUp;g->hp=YELLOW_MAX_HP;
    g->rng=0x5733CC11u;g->pika_level=5;
    g->experience=y_exp_threshold(YK_PIKACHU,5);
    g->pika_pp[0]=y_max_pp(YM_THUNDERSHOCK);
    g->pika_pp[1]=y_max_pp(YM_GROWL);
    g->running=true;g->story=YStoryBeforeOak;
    open_dialog(g,intro,3,YPendingNone);
}
uint8_t yellow_player_max_hp(const YellowGame* g) {
    return y_calc_stats(YK_PIKACHU,g->pika_level).hp;
}
void yellow_heal_pikachu(YellowGame* g) {
    g->hp=yellow_player_max_hp(g);
    for(unsigned i=0;i<3;i++) {
        g->pika_pp[i]=y_max_pp(y_player_move(g->pika_level,(uint8_t)i));
    }
}
void yellow_begin_battle(YellowGame* g,uint8_t kind,uint8_t level) {
    if(kind>YK_RATTATA||!level) return;
    g->foe_kind=kind;g->foe_level=level;
    g->foe_max_hp=y_calc_stats(kind,level).hp;
    g->foe_hp=g->foe_max_hp;
    g->foe_attack_stage=0;g->foe_defense_stage=0;
    g->pika_attack_stage=0;g->pika_defense_stage=0;
    g->foe_attack_debuff=0;
    g->last_exp_award=0;
    g->selected=0;g->screen=YScreenRivalBattle;
}
static void grant_exp(YellowGame* g) {
    if(!g->has_pikachu || g->pika_level>=100)return;
    g->last_exp_award=y_exp_award(g->foe_kind,g->foe_level,g->foe_kind==YK_EEVEE);
    g->experience+=g->last_exp_award;
    while(g->pika_level<100 &&
          g->experience>=y_exp_threshold(YK_PIKACHU,(uint8_t)(g->pika_level+1))) {
        uint8_t old_hp=yellow_player_max_hp(g);
        g->pika_level++;
        uint8_t hp=yellow_player_max_hp(g);
        g->hp=(uint8_t)(g->hp+(hp-old_hp));
        if(g->pika_level==6)g->pika_pp[2]=y_max_pp(YM_TAIL_WHIP);
    }
}
static void finalize_battle(YellowGame* g,bool won) {
    if(won)grant_exp(g);
    g->foe_hp=0;g->foe_attack_debuff=0;
    if(g->foe_kind!=0) {
        if(!won) {
            yellow_heal_pikachu(g);
            set_map(g,YMapRedsHouse,3,6);
        }
        open_dialog(g,won?wild_victory:wild_defeat,1,YPendingEndWildBattle);
    } else {
        if(!won)yellow_heal_pikachu(g);
        open_dialog(g,won?victory_text:defeat_text,1,YPendingEndBattle);
    }
}
static void resolve_pending(YellowGame* g) {
    YellowPending pending=g->pending;
    g->pending=YPendingNone;
    g->screen=YScreenWorld;
    switch(pending) {
    case YPendingBeginCapture:
        g->story=YStoryOakEncounter;g->screen=YScreenOakEncounter;break;
    case YPendingEnterLab:
        g->story=YStoryChooseStarter;
        set_map(g,YMapOaksLab,4,8);
        open_dialog(g,lab_intro,3,YPendingNone);
        break;
    case YPendingStartBattle:
        g->story=YStoryRivalBattle;
        g->has_pikachu=1;yellow_heal_pikachu(g);
        yellow_begin_battle(g,YK_EEVEE,5);
        open_dialog(g,challenge_text,2,YPendingBeginRivalBattle);
        break;
    case YPendingBeginRivalBattle:
        g->screen=YScreenRivalBattle;
        break;
    case YPendingEndWildBattle:
        /* Wild battle ended; only state in the local overworld resumes. */
        break;
    case YPendingEndBattle:
        g->story=YStoryPikachuFollows;
        set_follower_near(g);
        open_dialog(g,follower_text,2,YPendingNone);
        break;
    case YPendingNone:default:break;
    }
}
static void do_step(YellowGame* g,YellowKey key) {
    int x=g->x,y=g->y;
    uint8_t previous_facing=g->facing;
    g->facing=(uint8_t)key;
    if(key==YUp)--y;
    else if(key==YDown)++y;
    else if(key==YLeft)--x;
    else if(key==YRight)++x;

    if(g->map==YMapPallet&&y==0&&(x==10||x==11)&&g->story==YStoryBeforeOak) {
        open_dialog(g,oak_warning,3,YPendingBeginCapture);
        return;
    }
    /* Outdoor map connections use original width/height and north -5 offset.
       Route 1 (20-step wide) aligns to Viridian City at +10 steps. */
    if(g->story==YStoryPikachuFollows&&key==YUp) {
        if(g->map==YMapPallet&&y<0&&(x==10||x==11)) {
            set_map(g,YMapRoute1,(uint8_t)x,35);g->steps++;return;
        }
        if(g->map==YMapRoute1&&y<0&&(x==10||x==11)) {
            set_map(g,YMapViridian,(uint8_t)(x+10),35);g->steps++;return;
        }
    }
    if(key==YDown) {
        if(g->map==YMapRoute1&&y>=36&&(x==10||x==11)) {
            set_map(g,YMapPallet,(uint8_t)x,0);g->steps++;return;
        }
        if(g->map==YMapViridian&&y>=36&&(x==20||x==21)) {
            set_map(g,YMapRoute1,(uint8_t)(x-10),0);g->steps++;return;
        }
    }
    /* First reversal toward a follower just faces it, allowing OK to talk.
       Repeating the same D-pad direction exchanges places instead of
       permanently trapping the player in a one-tile-wide passage. */
    if(g->story==YStoryPikachuFollows && g->follower_valid &&
       g->follower_map==g->map && x==g->follower_x && y==g->follower_y &&
       previous_facing!=(uint8_t)key) return;
    if(!yellow_walkable(g,x,y))return;
    uint8_t map=g->map,dx,dy;
    if(destination(g->map,x,y,&map,&dx,&dy)) {
        set_map(g,map,dx,dy);
    } else {
        if(g->story==YStoryPikachuFollows&&g->has_pikachu) {
            g->follower_map=g->map;g->follower_x=(uint8_t)g->x;
            g->follower_y=(uint8_t)g->y;g->follower_valid=1;
        }
        g->x=(int8_t)x;g->y=(int8_t)y;
    }
    ++g->steps;
    if(g->map==YMapRoute1&&g->has_pikachu&&g->hp>0&&
       yellow_is_grass(g->map,g->x,g->y) &&
       (next_rng(g)&255u)<25u) {
        uint8_t roll=(uint8_t)(next_rng(g)&255u);
        int slot=0, sum=0;
        while(slot<9) {
            sum+=encounter_weights[slot];
            if(roll<sum)break;
            ++slot;
        }
        yellow_begin_battle(g,route1_kinds[slot],route1_levels[slot]);
    }
}
bool yellow_is_grass(uint8_t map,int x,int y) {
    return map==YMapRoute1 && yellow_tile_id(map,x*2,y*2+1)==0x52;
}
static void interact(YellowGame* g) {
    int x=g->x,y=g->y;
    if(g->facing==YUp)--y;
    else if(g->facing==YDown)++y;
    else if(g->facing==YLeft)--x;
    else if(g->facing==YRight)++x;

    if(g->story==YStoryPikachuFollows&&g->follower_valid&&
       g->follower_map==g->map&&x==g->follower_x&&y==g->follower_y) {
        if(g->affection<255)g->affection++;
        open_dialog(g,g->affection%3?pika_happy:pika_normal,1,YPendingNone);
        return;
    }
    /* The Gen1 nurse talks across a one-step Pokecenter counter. */
    if(g->map==YMapViridianCenter&&x==3&&y==2&&g->facing==YUp) {
        yellow_heal_pikachu(g);
        dialog_id(g,TalkViridianCenter);
        return;
    }
    for(uint8_t i=0;i<yellow_npc_count;i++) {
        const YellowNpc* n=&yellow_npcs[i];
        if(n->x==x&&n->y==y&&yellow_npc_visible(g,n)) {
            if(n->type==YActorNurse)yellow_heal_pikachu(g);
            if(n->map==YMapOaksLab&&n->type==YActorPokeBall) {
                if(g->story==YStoryChooseStarter) {
                    open_dialog(g,starter_text,3,YPendingStartBattle);
                } else open_dialog(g,empty_ball,1,YPendingNone);
                return;
            }
            if(n->map==YMapOaksLab&&g->story==YStoryBeforeOak&&n->type==YActorOak)
                open_dialog(g,early_lab,1,YPendingNone);
            else dialog_id(g,n->dialog_id);
            return;
        }
    }
    if(g->map==YMapPallet) {
        if(x==13&&y==13){dialog_id(g,TalkLabSign);return;}
        if(x==7&&y==9){dialog_id(g,TalkTownSign);return;}
        if(x==3&&y==5){dialog_id(g,TalkHomeSign);return;}
        if(x==11&&y==5){dialog_id(g,TalkRivalSign);return;}
    }
    if(g->map==YMapRedsHouse&&x==3&&y==1)dialog_id(g,TalkTV);
    if(g->map==YMapRoute1&&x==9&&y==27)dialog_id(g,TalkRouteSign);
    if(g->map==YMapViridian) {
        if(x==17&&y==17){dialog_id(g,TalkViridianSign);return;}
        if(x==24&&y==25){dialog_id(g,TalkViridianSign);return;}
    }
}
static void enemy_turn(YellowGame* g) {
    /* Gen1 original level-1 moves: Eevee Tackle/Tail Whip,
       Pidgey Gust, Rattata Tackle. No full AI or status engine yet. */
    uint8_t move=YM_TACKLE;
    if(g->foe_kind==YK_PIDGEY)move=YM_GUST;
    else if(g->foe_kind!=YK_PIDGEY && (next_rng(g)&7u)==0)
        move=YM_TAIL_WHIP;
    YDamage d=y_calc_damage(g->foe_kind,g->foe_level,YK_PIKACHU,g->pika_level,
                           move,g->foe_attack_stage,g->pika_defense_stage,
                           (uint8_t)next_rng(g),(uint8_t)next_rng(g));
    if(d.hit&&move==YM_TAIL_WHIP) {
        if(g->pika_defense_stage>-6)g->pika_defense_stage--;
    } else if(d.hit&&d.damage) {
        if(g->hp<=d.damage){finalize_battle(g,false);return;}
        g->hp-=d.damage;
    }
    g->screen=YScreenRivalBattle;
}
static void battle_move(YellowGame* g) {
    uint8_t move_count=y_player_move_count(g->pika_level);
    if(g->selected==move_count) {
        /* Rival trainer battles cannot be escaped. */
        if(g->foe_kind!=YK_EEVEE&&(next_rng(g)&3u)!=0u) {
            g->foe_hp=0;
            open_dialog(g,wild_flee,1,YPendingEndWildBattle);
        } else if(g->foe_kind!=YK_EEVEE)enemy_turn(g);
        else g->screen=YScreenRivalBattle;
        return;
    }
    if(g->selected>=move_count || g->selected>=3 || !g->pika_pp[g->selected])
        return;
    uint8_t move=y_player_move(g->pika_level,g->selected);
    g->pika_pp[g->selected]--;
    YDamage d=y_calc_damage(YK_PIKACHU,g->pika_level,g->foe_kind,g->foe_level,
                           move,g->pika_attack_stage,g->foe_defense_stage,
                           (uint8_t)next_rng(g),(uint8_t)next_rng(g));
    if(d.hit&&move==YM_GROWL) {
        if(g->foe_attack_stage>-6)g->foe_attack_stage--;
    } else if(d.hit&&move==YM_TAIL_WHIP) {
        if(g->foe_defense_stage>-6)g->foe_defense_stage--;
    } else if(d.hit&&d.damage) {
        if(g->foe_hp<=d.damage){finalize_battle(g,true);return;}
        g->foe_hp-=d.damage;
    }
    enemy_turn(g);
}
void yellow_input(YellowGame* g,YellowKey key) {
    if(!g->running)return;
    switch(g->screen) {
    case YScreenWorld:
        if(key<=YRight)do_step(g,key);
        else if(key==YOk)interact(g);
        else if(key==YBack){g->screen=YScreenMenu;g->selected=0;}
        break;
    case YScreenDialog:
        if(key==YOk||key==YBack) {
            if(++g->dialog_page>=g->dialog_count)resolve_pending(g);
        }
        break;
    case YScreenOakEncounter:
        if(key==YOk)open_dialog(g,capture_text,3,YPendingEnterLab);
        break;
    case YScreenRivalBattle:
        if(key==YOk){g->selected=0;g->screen=YScreenFightMenu;}
        break;
    case YScreenFightMenu:
        if(key==YUp&&g->selected)g->selected--;
        else if(key==YDown&&g->selected<y_player_move_count(g->pika_level))g->selected++;
        else if(key==YBack)g->screen=YScreenRivalBattle;
        else if(key==YOk)battle_move(g);
        break;
    case YScreenMenu:
        if(key==YUp&&g->selected)g->selected--;
        else if(key==YDown&&g->selected<3)g->selected++;
        else if(key==YBack)g->screen=YScreenWorld;
        else if(key==YOk) {
            if(g->selected==0)g->screen=YScreenParty;
            else if(g->selected==1)g->screen=YScreenBag;
            else if(g->selected==2){g->request_save=true;g->message_saved=false;}
            else g->running=false;
        }
        break;
    case YScreenParty:case YScreenBag:
        if(key==YOk||key==YBack){
            uint8_t selected=(g->screen==YScreenParty)?0:1;
            g->screen=YScreenMenu;g->selected=selected;
        }
        break;
    }
}
static uint32_t checksum(const YellowSave* s) {
    /* Explicit serialization-independent checksum, no uninitialized padding. */
    uint32_t c=0xA54C537Bu;
    c^=s->magic^((uint32_t)s->version<<16);
    c^=(uint32_t)s->map<<24 ^ (uint32_t)s->x<<16 ^ (uint32_t)s->y<<8 ^ s->facing;
    c^=(uint32_t)s->hp<<24 ^ (uint32_t)s->potions<<16 ^ (uint32_t)s->story<<8 ^ s->has_pikachu;
    c^=(uint32_t)s->affection<<24 ^ (uint32_t)s->foe_hp<<16 ^ s->steps;
    c^=(uint32_t)s->foe_kind<<24 ^ (uint32_t)s->foe_level<<16 ^
       (uint32_t)s->foe_max_hp<<8 ^ s->pika_level;
    c^=(uint32_t)s->follower_map<<24 ^ (uint32_t)s->follower_x<<16 ^
       (uint32_t)s->follower_y<<8 ^ s->follower_valid;
    c^=s->experience;
    for(unsigned i=0;i<3;i++)c=(c*16777619u)^s->pika_pp[i];
    return c^s->rng;
}
void yellow_save_create(const YellowGame* g,YellowSave* s) {
    memset(s,0,sizeof(*s));
    s->magic=YELLOW_SAVE_MAGIC;s->version=5;
    s->map=g->map;s->x=(uint8_t)g->x;s->y=(uint8_t)g->y;
    s->facing=g->facing;s->hp=g->hp;s->potions=g->potions;
    s->story=(uint8_t)g->story;s->has_pikachu=g->has_pikachu;s->affection=g->affection;
    s->foe_hp=g->foe_hp;s->foe_kind=g->foe_kind;
    s->foe_level=g->foe_level;s->foe_max_hp=g->foe_max_hp;s->pika_level=g->pika_level;
    s->follower_map=g->follower_map;
    s->follower_x=g->follower_x;s->follower_y=g->follower_y;
    s->follower_valid=g->follower_valid;s->steps=g->steps;s->rng=g->rng;
    s->experience=g->experience;
    for(unsigned i=0;i<3;i++)s->pika_pp[i]=g->pika_pp[i];
    s->checksum=checksum(s);
}
bool yellow_save_load(YellowGame* g,const YellowSave* s) {
    if(s->magic!=YELLOW_SAVE_MAGIC||s->version!=5||
       s->map>=YELLOW_MAP_COUNT||s->x>=yellow_map_w(s->map)||
       s->y>=yellow_map_h(s->map)||s->facing>YRight||
       s->hp==0||s->pika_level<5||s->pika_level>100||
       s->hp>y_calc_stats(YK_PIKACHU,s->pika_level).hp||
       s->foe_kind>2||s->foe_level>100||
       s->experience<y_exp_threshold(YK_PIKACHU,s->pika_level)||
       (s->pika_level<100&&s->experience>=y_exp_threshold(YK_PIKACHU,(uint8_t)(s->pika_level+1)))||
       s->pika_pp[0]>y_max_pp(YM_THUNDERSHOCK)||
       s->pika_pp[1]>y_max_pp(YM_GROWL)||
       s->pika_pp[2]>(s->pika_level>=6?y_max_pp(YM_TAIL_WHIP):0)||
       s->story>YStoryPikachuFollows||
       (s->story==YStoryPikachuFollows&&!s->has_pikachu)||
       (s->has_pikachu&&s->story<YStoryRivalBattle)||
       (s->follower_valid&&(s->follower_map>=YELLOW_MAP_COUNT||
           s->follower_x>=yellow_map_w(s->follower_map)||
           s->follower_y>=yellow_map_h(s->follower_map)))||
       s->checksum!=checksum(s))return false;
    YellowGame tmp={0};tmp.map=s->map;tmp.story=(YellowStory)s->story;
    if(!yellow_walkable(&tmp,s->x,s->y))return false;

    yellow_init(g);
    g->map=s->map;g->x=(int8_t)s->x;g->y=(int8_t)s->y;g->facing=s->facing;
    g->hp=s->hp;g->potions=s->potions;g->steps=s->steps;
    g->story=(YellowStory)s->story;g->has_pikachu=s->has_pikachu;
    g->affection=s->affection;g->foe_hp=s->foe_hp;g->rng=s->rng;
    g->foe_kind=s->foe_kind;g->foe_level=s->foe_level;
    g->foe_max_hp=s->foe_max_hp;g->pika_level=s->pika_level;
    g->experience=s->experience;
    for(unsigned i=0;i<3;i++)g->pika_pp[i]=s->pika_pp[i];
    g->screen=YScreenWorld;g->pending=YPendingNone;
    set_follower_near(g); /* rebuild follower, do not trust saved stale coordinates */
    return true;
}
