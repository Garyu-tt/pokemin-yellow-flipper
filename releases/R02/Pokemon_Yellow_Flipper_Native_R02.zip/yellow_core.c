#include "yellow_core.h"
#include "yellow_assets.h"
#include <string.h>

/* Game Boy map block binaries + collision tile sets from pret/pokeyellow.
   Coordinates/warps/NPCs match data/maps/objects/{PalletTown,RedsHouse1F,
   BluesHouse,OaksLab}. Intro, Oak's complete scripts and battles are not ported. */

enum {
    TalkOak,TalkGirl,TalkFisher,TalkMom,TalkDaisy,TalkRival,
    TalkLabOak,TalkLabGirl,TalkScientist,TalkTownSign,TalkLabSign,
    TalkHomeSign,TalkRivalSign,TalkMap,TalkTV,TalkExit,TalkNorth
};
const YellowNpc yellow_npcs[]={
    {YMapPallet,10,4,YActorOak,TalkOak},
    {YMapPallet,3,8,YActorGirl,TalkGirl},
    {YMapPallet,11,14,YActorFisher,TalkFisher},
    {YMapRedsHouse,5,4,YActorMom,TalkMom},
    {YMapBluesHouse,2,3,YActorDaisy,TalkDaisy},
    {YMapBluesHouse,6,4,YActorDaisy,TalkDaisy},
    {YMapBluesHouse,3,3,YActorPokedex,TalkMap},
    {YMapOaksLab,4,3,YActorBlue,TalkRival},
    {YMapOaksLab,7,3,YActorPokeBall,TalkLabOak},
    {YMapOaksLab,5,2,YActorOak,TalkLabOak},
    {YMapOaksLab,5,10,YActorOak,TalkLabOak},
    {YMapOaksLab,1,9,YActorGirl,TalkLabGirl},
    {YMapOaksLab,2,10,YActorScientist,TalkScientist},
    {YMapOaksLab,8,10,YActorScientist,TalkScientist}
};
const uint8_t yellow_npc_count=(uint8_t)(sizeof(yellow_npcs)/sizeof(yellow_npcs[0]));

static const char* const d_intro[]={
    "PALLET TOWN","THE START OF KANTO",
    "ORIGINAL MAP DATA","128X64 NATIVE VIEW",
    "D-PAD TO MOVE","OK TO INTERACT"
};
static const char* const d_oak[]={
    "OAK: Hey! Wait!","Don't go out!",
    "OAK: That was close!","Wild POKEMON live",
    "in tall grass!","(script in progress)"
};
static const char* const d_girl[]={
    "I'm raising","POKEMON too!",
    "When they get","strong, they can",
    "protect me!",""
};
static const char* const d_fisher[]={
    "Technology is","incredible!",
    "You can now store","and recall items",
    "and POKEMON as","data via PC!"
};
static const char* const d_mom[]={
    "MOM: All boys leave","home some day.",
    "It said so on TV.",""
};
static const char* const d_daisy[]={
    "DAISY: Hi!","Nice to see you."
};
static const char* const d_rival[]={
    "RIVAL: Gramps","isn't around!",
    "(story events","not ported yet)"
};
static const char* const d_lab_oak[]={
    "PROF. OAK'S LAB","(story port pending)"
};
static const char* const d_lab_girl[]={
    "OAK'S LAB ASSISTANT","HELLO!"
};
static const char* const d_scientist[]={
    "RESEARCHER:","POKEMON ARE AMAZING!"
};
static const char* const d_town_sign[]={
    "PALLET TOWN","Shades of your",
    "journey await!",""
};
static const char* const d_lab_sign[]={"OAK POKEMON","RESEARCH LAB"};
static const char* const d_home_sign[]={"PLAYER'S HOUSE",""};
static const char* const d_rival_sign[]={"RIVAL'S HOUSE",""};
static const char* const d_townmap[]={"KANTO TOWN MAP","(not ported yet)"};
static const char* const d_tv[]={"A TV SET.",""};
static const char* const d_exit[]={"ROUTE CONNECTION","(not ported yet)"};
static const char* const d_north[]={
    "OAK: Hey! Wait!","Don't go out!",
    "There's wild","POKEMON in grass!",
    "Come with me!","(script coming soon)"
};
typedef struct {const char* const* lines;uint8_t pages;} DialogDef;
static const DialogDef dialogs[]={
    {d_oak,3},{d_girl,3},{d_fisher,3},{d_mom,2},{d_daisy,1},
    {d_rival,2},{d_lab_oak,1},{d_lab_girl,1},{d_scientist,1},
    {d_town_sign,2},{d_lab_sign,1},{d_home_sign,1},{d_rival_sign,1},
    {d_townmap,1},{d_tv,1},{d_exit,1},{d_north,3}
};
static void dialog_open(YellowGame* g,const char* const* text,uint8_t pages) {
    g->dialog_lines=text;g->dialog_count=pages;g->dialog_page=0;
    g->screen=YScreenDialog;
}
static void dialog_id(YellowGame* g,uint8_t id) {
    if(id>=sizeof(dialogs)/sizeof(dialogs[0]))return;
    dialog_open(g,dialogs[id].lines,dialogs[id].pages);
}

int yellow_map_w(uint8_t map) {
    return map<YELLOW_MAP_COUNT?yellow_levels[map].w*2:0;
}
int yellow_map_h(uint8_t map) {
    return map<YELLOW_MAP_COUNT?yellow_levels[map].h*2:0;
}
uint8_t yellow_tile_id(uint8_t map,int tile_x,int tile_y) {
    if(map>=YELLOW_MAP_COUNT)return 0xff;
    const YellowLevelAsset* a=&yellow_levels[map];
    if(tile_x<0||tile_y<0||tile_x>=a->w*4||tile_y>=a->h*4)return 0xff;
    uint8_t block=a->map[(tile_y/4)*a->w+(tile_x/4)];
    if(block>=a->blocks_count)return 0xff;
    uint8_t index=a->blocks[block*16+(tile_y%4)*4+(tile_x%4)];
    return index<a->tiles_count?index:0xff;
}
static bool base_passable(uint8_t map,int x,int y) {
    if(map>=YELLOW_MAP_COUNT||x<0||y<0||x>=yellow_map_w(map)||y>=yellow_map_h(map))return false;
    uint8_t tile=yellow_tile_id(map,x*2+1,y*2+1);
    return tile<96&&yellow_levels[map].collision[tile]!=0;
}
static bool npc_at(uint8_t map,int x,int y) {
    for(uint8_t i=0;i<yellow_npc_count;i++)
        if(yellow_npcs[i].map==map&&yellow_npcs[i].x==x&&yellow_npcs[i].y==y)
            return true;
    return false;
}
static int destination(uint8_t map,int x,int y, uint8_t* target,uint8_t* nx,uint8_t* ny) {
    if(map==YMapPallet) {
        if(x==5&&y==5) {*target=YMapRedsHouse;*nx=2;*ny=6;return 1;}
        if(x==13&&y==5) {*target=YMapBluesHouse;*nx=2;*ny=6;return 1;}
        if(x==12&&y==11){*target=YMapOaksLab;*nx=4;*ny=10;return 1;}
    } else if(map==YMapRedsHouse) {
        if((x==2||x==3)&&y==7) {*target=YMapPallet;*nx=5;*ny=6;return 1;}
    } else if(map==YMapBluesHouse) {
        if((x==2||x==3)&&y==7){*target=YMapPallet;*nx=13;*ny=6;return 1;}
    } else if(map==YMapOaksLab) {
        if((x==4||x==5)&&y==11){*target=YMapPallet;*nx=12;*ny=12;return 1;}
    }
    return 0;
}
bool yellow_walkable(const YellowGame* g,int x,int y) {
    uint8_t target,nx,ny;
    if(destination(g->map,x,y,&target,&nx,&ny))return true;
    return base_passable(g->map,x,y)&&!npc_at(g->map,x,y);
}

void yellow_init(YellowGame* g) {
    memset(g,0,sizeof(*g));
    g->map=YMapPallet;
    g->x=10;g->y=12;
    g->facing=YUp;g->hp=YELLOW_MAX_HP;g->potions=0;
    g->running=true;
    dialog_open(g,d_intro,3);
}
static void do_step(YellowGame* g,YellowKey key) {
    int nx=g->x,ny=g->y;
    g->facing=(uint8_t)key;
    if(key==YUp)ny--;
    else if(key==YDown)ny++;
    else if(key==YLeft)nx--;
    else if(key==YRight)nx++;
    if(g->map==YMapPallet&&ny==0&&(nx==10||nx==11)) {
        if(!g->oak_visited){g->oak_visited=true;dialog_id(g,TalkNorth);}
        else dialog_id(g,TalkExit);
        return;
    }
    if(!yellow_walkable(g,nx,ny))return;
    uint8_t map=g->map,x,y;
    if(destination(map,nx,ny,&map,&x,&y)) {
        g->map=map;g->x=(int8_t)x;g->y=(int8_t)y;
    } else {
        g->x=(int8_t)nx;g->y=(int8_t)ny;
    }
    ++g->steps;
}
static void interact(YellowGame* g) {
    int x=g->x,y=g->y;
    if(g->facing==YUp)--y;
    else if(g->facing==YDown)++y;
    else if(g->facing==YLeft)--x;
    else if(g->facing==YRight)++x;
    for(uint8_t i=0;i<yellow_npc_count;i++) {
        const YellowNpc* n=&yellow_npcs[i];
        if(n->map==g->map&&n->x==x&&n->y==y) {
            dialog_id(g,n->dialog_id);return;
        }
    }
    if(g->map==YMapPallet) {
        if(x==13&&y==13){dialog_id(g,TalkLabSign);return;}
        if(x==7&&y==9){dialog_id(g,TalkTownSign);return;}
        if(x==3&&y==5){dialog_id(g,TalkHomeSign);return;}
        if(x==11&&y==5){dialog_id(g,TalkRivalSign);return;}
    }
    if(g->map==YMapRedsHouse&&x==3&&y==1)dialog_id(g,TalkTV);
}
void yellow_input(YellowGame* g,YellowKey key) {
    if(!g->running)return;
    switch(g->screen) {
    case YScreenWorld:
        if(key<=YRight)do_step(g,key);
        else if(key==YOk)interact(g);
        else if(key==YBack){g->screen=YScreenMenu;g->selected=0;}
        break;
    case YScreenDialog:
        if(key==YOk||key==YBack) {
            if(++g->dialog_page>=g->dialog_count)g->screen=YScreenWorld;
        }
        break;
    case YScreenMenu:
        if(key==YUp&&g->selected)g->selected--;
        else if(key==YDown&&g->selected<3)g->selected++;
        else if(key==YBack)g->screen=YScreenWorld;
        else if(key==YOk){
            if(g->selected==0)g->screen=YScreenParty;
            else if(g->selected==1)g->screen=YScreenBag;
            else if(g->selected==2){g->request_save=true;g->message_saved=false;}
            else g->running=false;
        }
        break;
    case YScreenParty:case YScreenBag:
        if(key==YOk||key==YBack){uint8_t selected=(g->screen==YScreenParty)?0:1;g->screen=YScreenMenu;g->selected=selected;}
        break;
    }
}
static uint32_t checksum(const YellowSave* s) {
    return 0x6c6f7761u^s->magic^s->version^
        ((uint32_t)s->map<<27)^((uint32_t)s->x<<24)^((uint32_t)s->y<<16)^
        ((uint32_t)s->facing<<8)^s->hp^((uint32_t)s->potions<<18)^
        ((uint32_t)s->intro_seen<<12)^((uint32_t)s->oak_visited<<14)^s->steps;
}
void yellow_save_create(const YellowGame* g,YellowSave* s) {
    memset(s,0,sizeof(*s));s->magic=YELLOW_SAVE_MAGIC;s->version=2;
    s->map=g->map;s->x=(uint8_t)g->x;s->y=(uint8_t)g->y;
    s->facing=g->facing;s->hp=g->hp;s->potions=g->potions;
    s->intro_seen=g->intro_seen;s->oak_visited=g->oak_visited;
    s->steps=g->steps;s->checksum=checksum(s);
}
bool yellow_save_load(YellowGame* g,const YellowSave* s) {
    if(s->magic!=YELLOW_SAVE_MAGIC||s->version!=2||
       s->map>=YELLOW_MAP_COUNT||s->x>=yellow_map_w(s->map)||
       s->y>=yellow_map_h(s->map)||s->facing>YRight||
       s->hp==0||s->hp>YELLOW_MAX_HP||
       s->checksum!=checksum(s))return false;
    YellowGame candidate={0};
    candidate.map=s->map;
    if(!yellow_walkable(&candidate,s->x,s->y))return false;
    yellow_init(g);g->map=s->map;g->x=(int8_t)s->x;g->y=(int8_t)s->y;
    g->facing=s->facing;g->hp=s->hp;g->potions=s->potions;
    g->intro_seen=s->intro_seen;g->oak_visited=s->oak_visited;g->steps=s->steps;
    g->screen=YScreenWorld;
    return true;
}
