# Pokemon Yellow Flipper Native — R0.2 (partial native port)

This is NOT the complete Pokemon Yellow game and NOT a Game Boy emulator. It builds as a native ARM Cortex-M4 FAP for Momentum mntm-012 SDK, API 87.1.

## What's actually here
- Original Pallet Town, Red's House 1F, Blue's House, Professor Oak's Lab maps from pret/pokeyellow binary `.blk` data (10x9, 4x4, 4x4, 5x6 original 32px blocks).
- Original tiles, block sets, walkable tile IDs and character graphics converted to 1-bit XBM without drawing new sprite anatomy.
- Native 128x64 camera displaying original pixel resolution, without squeezing Game Boy frames.
- Door/warp transitions and static NPC coordinates from upstream object event tables.
- Small excerpt dialogue panes and map signs, fullscreen menu, versioned microSD save.
- Offline map-reachability check using the original block collision data.

## Not yet ported
- Opening cutscene and full Oak/Pikachu capture scripting, battles and Pokemon battle rules, entire Kanto, dynamic NPC behaviors, inventory and monster management, audio, Gen1 accuracy. No claims otherwise.

## Existing data preserved
- Does NOT touch Flipper firmware or Noosphere Pika. App id: yellow_native; paths /ext/apps/Games/yellow_native.fap and /ext/apps_data/yellow_native/save_v02.dat.
- R0.1 save file `save.dat` is preserved; R0.2 uses a distinct save format/version.

## Build
Requires the Momentum uFBT SDK matching version `mntm-012`. Place `application.fam`, `yellow_flipper.c`, `yellow_core.h`, `yellow_core.c`, `yellow_assets.h` together; build with uFBT against API 87.1. Do not upload without verifying device firmware SDK version.

## Controls
D-Pad move; OK interact; Back open menu; OK advance dialog; Back exit submenu; menu Save writes SD state; menu Exit closes.

## Asset attribution
Source https://github.com/pret/pokeyellow . Script tools/generate_assets.py regenerates the asset header from a local checkout of the upstream source at /tmp/pokeyellow. Data/art is from Pokemon Yellow. This package is for private development/testing, not a license to redistribute Nintendo content.
