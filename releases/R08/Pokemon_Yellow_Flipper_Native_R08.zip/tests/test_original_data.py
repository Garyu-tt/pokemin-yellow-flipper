#!/usr/bin/env python3
"""Fail if the R0.5 Pokémon stats/moves diverge from the pinned disassembly."""
from pathlib import Path
import re,os
root=Path(os.environ.get("PKYELLOW_SOURCE",
 str(Path(__file__).resolve().parents[2]/"upstream/pokeyellow")))
source=(root/"data/moves/moves.asm").read_text()
expected_moves={
 "GUST":("40","NORMAL","100","35"),
 "TACKLE":("35","NORMAL","95","35"),
 "TAIL_WHIP":("0","NORMAL","100","30"),
 "GROWL":("0","NORMAL","100","40"),
 "THUNDERSHOCK":("40","ELECTRIC","100","30"),
 "QUICK_ATTACK":("40","NORMAL","100","30")
}
for name,vals in expected_moves.items():
 pattern=r"\bmove\s+"+name+r",\s*[^,]+,\s*(\d+),\s*([A-Z_]+),\s*(\d+),\s*(\d+)"
 m=re.search(pattern,source)
 assert m,(name,"not found")
 assert m.groups()==vals,(name,m.groups(),vals)
for name,stats,exp,growth in [
 ("pikachu",[35,55,30,90,50],82,"GROWTH_MEDIUM_FAST"),
 ("eevee",[55,55,50,55,65],92,"GROWTH_MEDIUM_FAST"),
 ("pidgey",[40,45,40,56,35],55,"GROWTH_MEDIUM_SLOW"),
 ("rattata",[30,56,35,72,25],57,"GROWTH_MEDIUM_FAST")
]:
 s=(root/"data/pokemon/base_stats"/(name+".asm")).read_text()
 m=re.search(r"db\s+(\d+),\s*(\d+),\s*(\d+),\s*(\d+),\s*(\d+)",s)
 assert m and list(map(int,m.groups()))==stats,(name,"stats",m.groups() if m else None)
 assert re.search(r"db\s+"+str(exp)+r"\s*; base exp",s), (name,"exp")
 assert growth in s,(name,"growth")
ev=(root/"data/pokemon/evos_moves.asm").read_text()
m=re.search(r"^PikachuEvosMoves:(.*?)(?=^RaichuEvosMoves:)",ev,re.M|re.S)
assert m
assert re.search(r"db\s+6,\s*TAIL_WHIP",m.group(1))
assert re.search(r"db\s+8,\s*THUNDER_WAVE",m.group(1))
# Extra R0.8 checks: original move effects and accuracy stage ratios.
effects={
 "SAND_ATTACK":"ACCURACY_DOWN1_EFFECT",
 "THUNDERSHOCK":"PARALYZE_SIDE_EFFECT1",
 "TAIL_WHIP":"DEFENSE_DOWN1_EFFECT",
 "GROWL":"ATTACK_DOWN1_EFFECT",
}
for name,effect in effects.items():
 assert re.search(r"\bmove\s+"+name+r",\s*"+effect+r",",source),(name,effect)
table=(root/"data/battle/stat_modifiers.asm").read_text()
pairs=re.findall(r"^\s*db\s+(\d+),\s*(\d+)",table,re.M)
assert [(int(a),int(b)) for a,b in pairs[:13]]==[
 (25,100),(28,100),(33,100),(40,100),(50,100),(66,100),
 (1,1),(15,10),(2,1),(25,10),(3,1),(35,10),(4,1)]
side=(root/"engine/battle/effects.asm").read_text()
assert "10 percent + 1" in side
core=(root/"engine/battle/core.asm").read_text()
assert "cp 25 percent" in core
capture=(root/"engine/items/item_effects.asm").read_text()
assert "Status = 12" in capture
print("R08_UPSTREAM_STATUS_ACCURACY_CAPTURE_CONSTANTS_PASS")
print("R05_UPSTREAM_SPECIES_MOVE_LEARNSET_PASS")
