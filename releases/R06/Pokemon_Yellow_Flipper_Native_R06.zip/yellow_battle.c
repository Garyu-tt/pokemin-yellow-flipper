#include "yellow_battle.h"

/*
 * Base stats, growth curves, move power/PP/type:
 * pret/pokeyellow data/pokemon/base_stats/<species>.asm,
 * data/pokemon/evos_moves.asm, data/moves/moves.asm.
 * Scope: starter and Route 1 encounters, fixed DV=15, zero StatExp.
 * This is an intentionally incomplete Gen1 implementation (no crit/EV/status).
 */
static const YSpeciesInfo mons[]={
    {"EEVEE",55,55,50,55,65,92,YT_NORMAL,YT_NORMAL,0},
    {"PIDGEY",40,45,40,56,35,55,YT_NORMAL,YT_FLYING,1},
    {"RATTATA",30,56,35,72,25,57,YT_NORMAL,YT_NORMAL,0},
    {"PIKACHU",35,55,30,90,50,82,YT_ELECTRIC,YT_ELECTRIC,0},
};
static const YMoveInfo moves[]={
    {"THUNDERSHOCK",40,100,30,YT_ELECTRIC,1},
    {"GROWL",0,100,40,YT_NORMAL,0},
    {"TAIL WHIP",0,100,30,YT_NORMAL,0},
    {"TACKLE",35,95,35,YT_NORMAL,0},
    {"GUST",40,100,35,YT_NORMAL,0}, /* Gen1 Gust is NORMAL */
    {"QUICK ATTACK",40,100,30,YT_NORMAL,0},
    {"SAND ATTACK",0,100,15,YT_NORMAL,0},
};
const YSpeciesInfo* y_species_info(uint8_t kind) {
    return kind<sizeof(mons)/sizeof(mons[0])?&mons[kind]:0;
}
const YMoveInfo* y_move_info(uint8_t id) {
    return id<sizeof(moves)/sizeof(moves[0])?&moves[id]:0;
}
static uint8_t calc_stat(uint8_t base,uint8_t level,bool hp) {
    if(level<1)level=1;
    /* Gen1 stat: DV=15; floor(sqrt(StatExp))=0 */
    uint32_t n=((2u*base+15u)*level)/100u;
    n+=hp?(uint32_t)level+10u:5u;
    return n>255u?255u:(uint8_t)n;
}
YBattleStats y_calc_stats(uint8_t kind,uint8_t level) {
    const YSpeciesInfo* p=y_species_info(kind);
    YBattleStats s={0};
    if(!p || !level)return s;
    s.hp=calc_stat(p->hp,level,true);
    s.attack=calc_stat(p->attack,level,false);
    s.defense=calc_stat(p->defense,level,false);
    s.speed=calc_stat(p->speed,level,false);
    s.special=calc_stat(p->special,level,false);
    return s;
}
uint32_t y_exp_threshold(uint8_t kind,uint8_t level) {
    const YSpeciesInfo* p=y_species_info(kind);
    if(!p || level>100)return 0;
    if(level<=1)return 0;
    uint32_t cube=(uint32_t)level*level*level;
    if(p->growth==0)return cube; /* medium fast */
    /* medium slow: 6/5*n^3-15*n^2+100*n-140, clamp at zero */
    int32_t v=(int32_t)(6*cube/5u)-(int32_t)(15u*level*level)+100*(int32_t)level-140;
    return (uint32_t)(v>0?v:0);
}
uint16_t y_exp_award(uint8_t kind,uint8_t level,bool trainer) {
    const YSpeciesInfo* p=y_species_info(kind);
    if(!p)return 0;
    uint32_t base=(uint32_t)p->exp_yield*level/7u;
    if(trainer)base=base*3u/2u;
    return base>65535u?65535u:(uint16_t)base;
}
uint8_t y_max_pp(uint8_t move) {
    const YMoveInfo* m=y_move_info(move);
    return m?m->pp:0;
}
uint8_t y_player_move(uint8_t level,uint8_t slot) {
    if(slot==0)return YM_THUNDERSHOCK;
    if(slot==1)return YM_GROWL;
    if(slot==2&&level>=6)return YM_TAIL_WHIP;
    return YM_NONE;
}
uint8_t y_player_move_count(uint8_t level) {
    return level>=6?3:2;
}
static uint16_t stage_factor(uint16_t stat,int8_t stage) {
    /* Gen1 stages: stat * (2+stage)/2 or stat * 2/(2-stage) */
    if(stage>6)stage=6;
    if(stage< -6)stage=-6;
    if(stage>=0)return (uint16_t)(stat*(2+stage)/2);
    return (uint16_t)(stat*2/(2-stage));
}
YDamage y_calc_damage(uint8_t source,uint8_t source_level,
                      uint8_t target,uint8_t target_level,
                      uint8_t move,int8_t atk_stage,int8_t def_stage,
                      uint8_t hit_roll,uint8_t rand_roll) {
    YDamage out={0,0};
    const YSpeciesInfo* a=y_species_info(source);
    const YSpeciesInfo* b=y_species_info(target);
    const YMoveInfo* m=y_move_info(move);
    if(!a||!b||!m||!source_level||!target_level)return out;
    if(hit_roll >= (uint32_t)m->accuracy*256u/100u)return out;
    out.hit=1;
    if(!m->power)return out;
    YBattleStats attacker=y_calc_stats(source,source_level);
    YBattleStats defender=y_calc_stats(target,target_level);
    uint16_t atk=m->special?attacker.special:stage_factor(attacker.attack,atk_stage);
    uint16_t def=m->special?defender.special:stage_factor(defender.defense,def_stage);
    if(!def)def=1;
    uint32_t damage=((((2u*source_level/5u+2u)*m->power*atk)/def)/50u)+2u;
    /* STAB and Gen1 electric super-effective against Flying, NOT normal */
    if(m->type==a->type1||m->type==a->type2)damage=damage*3u/2u;
    if(m->type==YT_ELECTRIC && (b->type1==YT_FLYING||b->type2==YT_FLYING))
        damage*=2u;
    /* Original Gen1 random multiplier 217..255, rounded */
    damage=damage*(217u+(rand_roll%39u))/255u;
    if(!damage)damage=1;
    out.damage=damage>255u?255u:(uint8_t)damage;
    return out;
}

/* Based on pret/pokeyellow engine/items/item_effects.asm ItemUseBall.
   Basic Poke Ball, no statuses and no Great/Ultra Ball adjustments.
   Original two RNG rolls and integer truncation. */
uint8_t y_species_catch_rate(uint8_t species) {
    switch(species) {
    case YK_PIKACHU:return 190;
    case YK_EEVEE:return 45;
    case YK_PIDGEY:case YK_RATTATA:return 255;
    default:return 0;
    }
}
bool y_gen1_pokeball_capture(uint8_t rate,uint8_t max_hp,
                             uint8_t hp,uint8_t r1,uint8_t r2) {
    if(!rate||!max_hp||!hp||hp>max_hp)return false;
    if(r1>rate)return false;
    uint32_t divisor=hp/4u;
    if(!divisor)divisor=1;
    uint32_t x=((uint32_t)max_hp*255u/12u)/divisor;
    return x>255u || r2<=x;
}

/* Initial low-level learnsets: evos_moves.asm and base_stats,
   before any player move replacement or enemy dynamic battle AI. */
uint8_t y_wild_move(uint8_t kind,uint8_t level,uint8_t slot) {
    if(kind==YK_PIDGEY) {
        if(slot==0)return YM_GUST;
        if(slot==1&&level>=5)return YM_SAND_ATTACK;
    }
    if(kind==YK_RATTATA) {
        if(slot==0)return YM_TACKLE;
        if(slot==1)return YM_TAIL_WHIP;
        if(slot==2&&level>=7)return YM_QUICK_ATTACK;
    }
    return YM_NONE;
}
