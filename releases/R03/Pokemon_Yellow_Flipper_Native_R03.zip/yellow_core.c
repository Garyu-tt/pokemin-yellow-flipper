#include "yellow_core.h"
#include "yellow_assets.h"
#include <string.h>

/*
 * Native game logic; original Gen 1 maps/tiles/overworld actors originate
 * from pret/pokeyellow. This is a limited adaptation of the opening sequence,
 * NOT a byte-identical implementation of Pokemon Yellow's battle formula,
 * movement scripts, or complete event engine.
 */

enum {
    TalkOak,TalkGirl,TalkFisher,TalkMom,TalkDaisy,TalkRival,
    TalkLabOak,TalkLabGirl,TalkScientist,TalkTownSign,TalkLabSign,
    TalkHomeSign,TalkRivalSign,TalkMap,TalkTV,TalkExit
};
const YellowNpc yellow_npcs[]={
    {YMapPallet,10,4,YActorOak,TalkOak},
    {YMapPallet,3,8,YActorGirl,TalkGirl},
    {YMapPallet,11,14,YActorFisher,TalkFisher},
    {YMapRedsHouse,5,4,YActorMom,TalkMom},
    {YMapBluesHouse,2,3,YActorDaisy,TalkDaisy},
    {YMapBluesHouse,6,4,YActorDaisy,TalkDaisy},
    {YMapBluesHouse,3,3,YActorPokedex,TalkMap},
    {YMapOaksLab,4,3,YActorBlue,TalkRival},
    {YMapOaksLab,7,3,YActorPokeBall,TalkLabOak},
    {YMapOaksLab,5,2,YActorOak,TalkLabOak},
    {YMapOaksLab,5,10,YActorOak,TalkLabOak},
    {YMapOaksLab,1,9,YActorGirl,TalkLabGirl},
    {YMapOaksLab,2,10,YActorScientist,TalkScientist},
    {YMapOaksLab,8,10,YActorScientist,TalkScientist},
};
const uint8_t yellow_npc_count=(uint8_t)(sizeof(yellow_npcs)/sizeof(yellow_npcs[0]));

static const char* const intro[]={
    "PALLET TOWN","YOUR JOURNEY BEGINS",
    "ORIGINAL MAP ART","NATIVE 128X64 VIEW",
    "D-PAD: MOVE","OK: INTERACT"
};
static const char* const oak_regular[]={"OAK: Be careful!","Tall grass is risky."};
static const char* const girl[]={
    "I'm raising","POKEMON too!",
    "When they get","strong, they can",
    "protect me!",""
};
static const char* const fisher[]={
    "Technology is","incredible!",
    "Items and POKEMON","can be stored",
    "as data in a PC.",""
};
static const char* const mom[]={"MOM: Travel safe!","Come back sometime."};
static const char* const daisy[]={"DAISY: Hi!","Nice to see you."};
static const char* const rival[]={"RIVAL: I'll show","you how it's done."};
static const char* const lab_oak[]={"OAK: Choose wisely.","(more events TODO)"};
static const char* const lab_girl[]={"OAK'S LAB ASSISTANT","HELLO!"};
static const char* const scientist[]={"RESEARCHER:","POKEMON ARE AMAZING!"};
static const char* const town_sign[]={"PALLET TOWN","Shades of your","journey await!",""};
static const char* const lab_sign[]={"OAK POKEMON","RESEARCH LAB"};
static const char* const home_sign[]={"PLAYER'S HOUSE",""};
static const char* const rival_sign[]={"RIVAL'S HOUSE",""};
static const char* const townmap[]={"KANTO TOWN MAP","(not ported yet)"};
static const char* const tv[]={"A TV SET.",""};
static const char* const exit_text[]={"ROUTE CONNECTION","(not ported yet)"};
static const char* const oak_warning[]={
    "OAK: HEY! WAIT!","DON'T GO OUT!",
    "WILD POKEMON LIVE","IN TALL GRASS!",
    "LET ME HELP YOU.",""
};
static const char* const capture_text[]={
    "OAK: PHEW!","THAT WAS CLOSE!",
    "OAK CAUGHT A","WILD PIKACHU.",
    "COME WITH ME TO","MY LAB!"
};
static const char* const lab_intro[]={
    "IN OAK'S LAB...","",
    "OAK: CHOOSE A","POKEMON.",
    "RIVAL: HMPH!","I WANT THAT BALL!"
};
static const char* const starter_text[]={
    "RIVAL GRABS","THE EEVEE BALL!",
    "OAK: TAKE THIS","PIKACHU INSTEAD.",
    "PIKACHU JOINED","YOUR PARTY!"
};
static const char* const challenge_text[]={
    "RIVAL: LET'S SEE","WHO IS STRONGER!",
    "PIKACHU VS EEVEE","LEVEL 5"
};
static const char* const victory_text[]={"RIVAL: HMPH!","I'LL WIN NEXT TIME!"};
static const char* const defeat_text[]={"PIKACHU FAINTED!","OAK HEALED IT."};
static const char* const follower_text[]={
    "PIKACHU DOESN'T","LIKE ITS POKE BALL.",
    "IT WILL FOLLOW","YOU EVERYWHERE!"
};
static const char* const pika_happy[]={"PIKA PIKA!","IT LOOKS HAPPY."};
static const char* const pika_normal[]={"PIKA?","IT LOOKS AT YOU."};
static const char* const early_lab[]={"OAK ISN'T HERE.","COME BACK LATER!"};
static const char* const north_text[]={"ROUTE 1","MORE MAPS TO COME"};
static const char* const empty_ball[]={"EMPTY POKE BALL","RIVAL TOOK EEVEE"};

typedef struct {const char* const* lines;uint8_t pages;} DialogDef;
static const DialogDef dialogs[]={
    {oak_regular,1},{girl,3},{fisher,3},{mom,1},{daisy,1},
    {rival,1},{lab_oak,1},{lab_girl,1},{scientist,1},
    {town_sign,2},{lab_sign,1},{home_sign,1},{rival_sign,1},
    {townmap,1},{tv,1},{exit_text,1}
};

static void open_dialog(YellowGame* g,const char* const* lines,uint8_t pages,YellowPending pending) {
    g->dialog_lines=lines;g->dialog_count=pages;
    g->dialog_page=0;g->pending=pending;g->screen=YScreenDialog;
}
static void dialog_id(YellowGame* g,uint8_t id) {
    if(id>=sizeof(dialogs)/sizeof(dialogs[0]))return;
    open_dialog(g,dialogs[id].lines,dialogs[id].pages,YPendingNone);
}

static uint32_t next_rng(YellowGame* g) {
    uint32_t x=g->rng?g->rng:0x96C08u;
    x^=x<<13;x^=x>>17;x^=x<<5;
    return g->rng=x?x:0xA53DCu;
}
int yellow_map_w(uint8_t map) {
    return map<YELLOW_MAP_COUNT?yellow_levels[map].w*2:0;
}
int yellow_map_h(uint8_t map) {
    return map<YELLOW_MAP_COUNT?yellow_levels[map].h*2:0;
}
uint8_t yellow_tile_id(uint8_t map,int x,int y) {
    if(map>=YELLOW_MAP_COUNT)return 0xff;
    const YellowLevelAsset* a=&yellow_levels[map];
    if(x<0||y<0||x>=a->w*4||y>=a->h*4)return 0xff;
    uint8_t block=a->map[(y/4)*a->w+x/4];
    if(block>=a->blocks_count)return 0xff;
    uint8_t id=a->blocks[block*16+(y%4)*4+(x%4)];
    return id<a->tiles_count?id:0xff;
}
bool yellow_npc_visible(const YellowGame* g,const YellowNpc* n) {
    if(g->map!=n->map)return false;
    if(n->map==YMapPallet&&n->type==YActorOak)
        return g->story==YStoryBeforeOak; /* Oak leaves Pallet in intro */
    if(n->map==YMapOaksLab) {
        if(n->type==YActorOak&&n->y==10)
            return g->story==YStoryOakEncounter;
        if(n->type==YActorOak&&n->y==2)
            return g->story>=YStoryChooseStarter;
        if(n->type==YActorPokeBall)
            return g->story<YStoryRivalBattle;
    }
    return true;
}
static bool npc_at(const YellowGame* g,int x,int y) {
    for(uint8_t i=0;i<yellow_npc_count;i++)
        if(yellow_npcs[i].x==x&&yellow_npcs[i].y==y&&
           yellow_npc_visible(g,&yellow_npcs[i]))return true;
    return false;
}
static bool base_passable(uint8_t map,int x,int y) {
    if(map>=YELLOW_MAP_COUNT||x<0||y<0||x>=yellow_map_w(map)||y>=yellow_map_h(map))
        return false;
    uint8_t tile=yellow_tile_id(map,x*2+1,y*2+1);
    return tile<96&&yellow_levels[map].collision[tile]!=0;
}
static bool destination(uint8_t map,int x,int y,uint8_t* target,uint8_t* dx,uint8_t* dy) {
    if(map==YMapPallet) {
        if(x==5&&y==5){*target=YMapRedsHouse;*dx=2;*dy=6;return true;}
        if(x==13&&y==5){*target=YMapBluesHouse;*dx=2;*dy=6;return true;}
        if(x==12&&y==11){*target=YMapOaksLab;*dx=4;*dy=10;return true;}
    } else if(map==YMapRedsHouse) {
        if((x==2||x==3)&&y==7){*target=YMapPallet;*dx=5;*dy=6;return true;}
    } else if(map==YMapBluesHouse) {
        if((x==2||x==3)&&y==7){*target=YMapPallet;*dx=13;*dy=6;return true;}
    } else if(map==YMapOaksLab) {
        if((x==4||x==5)&&y==11){*target=YMapPallet;*dx=12;*dy=12;return true;}
    }
    return false;
}
bool yellow_walkable(const YellowGame* g,int x,int y) {
    uint8_t target,dx,dy;
    if(destination(g->map,x,y,&target,&dx,&dy))return true;
    return base_passable(g->map,x,y)&&!npc_at(g,x,y);
}
static void set_follower_near(YellowGame* g) {
    g->follower_valid=0;
    if(g->story!=YStoryPikachuFollows||!g->has_pikachu)return;
    static const int8_t delta[][2]={{0,1},{0,-1},{-1,0},{1,0}};
    for(int i=0;i<4;i++) {
        int x=g->x+delta[i][0],y=g->y+delta[i][1];
        if(yellow_walkable(g,x,y)) {
            g->follower_map=g->map;g->follower_x=(uint8_t)x;
            g->follower_y=(uint8_t)y;g->follower_valid=1;return;
        }
    }
}
static void set_map(YellowGame* g,uint8_t map,uint8_t x,uint8_t y) {
    g->map=map;g->x=(int8_t)x;g->y=(int8_t)y;
    set_follower_near(g);
}
void yellow_init(YellowGame* g) {
    memset(g,0,sizeof(*g));g->map=YMapRedsHouse;
    g->x=3;g->y=6;g->facing=YUp;g->hp=YELLOW_MAX_HP;
    g->rng=0x5733CC11u;g->running=true;g->story=YStoryBeforeOak;
    open_dialog(g,intro,3,YPendingNone);
}
static void finalize_battle(YellowGame* g,bool won) {
    if(!won)g->hp=YELLOW_MAX_HP;
    g->foe_hp=0;g->foe_attack_debuff=0;
    open_dialog(g,won?victory_text:defeat_text,1,YPendingEndBattle);
}
static void resolve_pending(YellowGame* g) {
    YellowPending pending=g->pending;
    g->pending=YPendingNone;
    g->screen=YScreenWorld;
    switch(pending) {
    case YPendingBeginCapture:
        g->story=YStoryOakEncounter;g->screen=YScreenOakEncounter;break;
    case YPendingEnterLab:
        g->story=YStoryChooseStarter;
        set_map(g,YMapOaksLab,4,8);
        open_dialog(g,lab_intro,3,YPendingNone);
        break;
    case YPendingStartBattle:
        g->story=YStoryRivalBattle;
        g->has_pikachu=1;g->hp=YELLOW_MAX_HP;
        g->foe_hp=YELLOW_RIVAL_MAX_HP;g->foe_attack_debuff=0;
        g->selected=0;
        open_dialog(g,challenge_text,2,YPendingBeginRivalBattle);
        break;
    case YPendingBeginRivalBattle:
        g->screen=YScreenRivalBattle;
        break;
    case YPendingEndBattle:
        g->story=YStoryPikachuFollows;
        set_follower_near(g);
        open_dialog(g,follower_text,2,YPendingNone);
        break;
    case YPendingNone:default:break;
    }
}
static void do_step(YellowGame* g,YellowKey key) {
    int x=g->x,y=g->y;
    uint8_t previous_facing=g->facing;
    g->facing=(uint8_t)key;
    if(key==YUp)--y;
    else if(key==YDown)++y;
    else if(key==YLeft)--x;
    else if(key==YRight)++x;

    if(g->map==YMapPallet&&y==0&&(x==10||x==11)) {
        if(g->story==YStoryBeforeOak)
            open_dialog(g,oak_warning,3,YPendingBeginCapture);
        else open_dialog(g,north_text,1,YPendingNone);
        return;
    }
    /* First reversal toward a follower just faces it, allowing OK to talk.
       Repeating the same D-pad direction exchanges places instead of
       permanently trapping the player in a one-tile-wide passage. */
    if(g->story==YStoryPikachuFollows && g->follower_valid &&
       g->follower_map==g->map && x==g->follower_x && y==g->follower_y &&
       previous_facing!=(uint8_t)key) return;
    if(!yellow_walkable(g,x,y))return;
    uint8_t map=g->map,dx,dy;
    if(destination(g->map,x,y,&map,&dx,&dy)) {
        set_map(g,map,dx,dy);
    } else {
        if(g->story==YStoryPikachuFollows&&g->has_pikachu) {
            g->follower_map=g->map;g->follower_x=(uint8_t)g->x;
            g->follower_y=(uint8_t)g->y;g->follower_valid=1;
        }
        g->x=(int8_t)x;g->y=(int8_t)y;
    }
    ++g->steps;
}
static void interact(YellowGame* g) {
    int x=g->x,y=g->y;
    if(g->facing==YUp)--y;
    else if(g->facing==YDown)++y;
    else if(g->facing==YLeft)--x;
    else if(g->facing==YRight)++x;

    if(g->story==YStoryPikachuFollows&&g->follower_valid&&
       g->follower_map==g->map&&x==g->follower_x&&y==g->follower_y) {
        if(g->affection<255)g->affection++;
        open_dialog(g,g->affection%3?pika_happy:pika_normal,1,YPendingNone);
        return;
    }
    for(uint8_t i=0;i<yellow_npc_count;i++) {
        const YellowNpc* n=&yellow_npcs[i];
        if(n->x==x&&n->y==y&&yellow_npc_visible(g,n)) {
            if(n->map==YMapOaksLab&&n->type==YActorPokeBall) {
                if(g->story==YStoryChooseStarter) {
                    open_dialog(g,starter_text,3,YPendingStartBattle);
                } else open_dialog(g,empty_ball,1,YPendingNone);
                return;
            }
            if(n->map==YMapOaksLab&&g->story==YStoryBeforeOak&&n->type==YActorOak)
                open_dialog(g,early_lab,1,YPendingNone);
            else dialog_id(g,n->dialog_id);
            return;
        }
    }
    if(g->map==YMapPallet) {
        if(x==13&&y==13){dialog_id(g,TalkLabSign);return;}
        if(x==7&&y==9){dialog_id(g,TalkTownSign);return;}
        if(x==3&&y==5){dialog_id(g,TalkHomeSign);return;}
        if(x==11&&y==5){dialog_id(g,TalkRivalSign);return;}
    }
    if(g->map==YMapRedsHouse&&x==3&&y==1)dialog_id(g,TalkTV);
}
static void enemy_turn(YellowGame* g) {
    uint8_t damage=(uint8_t)(2+(next_rng(g)%3));
    if(g->foe_attack_debuff&&damage>1)--damage;
    if(g->hp<=damage)finalize_battle(g,false);
    else {g->hp-=damage;g->screen=YScreenRivalBattle;}
}
static void battle_move(YellowGame* g) {
    switch(g->selected) {
    case 0: {
        uint8_t damage=(uint8_t)(5+(next_rng(g)%4));
        if(g->foe_hp<=damage){finalize_battle(g,true);return;}
        g->foe_hp-=damage;enemy_turn(g);break;
    }
    case 1:
        g->foe_attack_debuff=1;enemy_turn(g);break;
    case 2: /* Pokemon Yellow's initial rival fight cannot be escaped */
        g->screen=YScreenRivalBattle;break;
    default:break;
    }
}
void yellow_input(YellowGame* g,YellowKey key) {
    if(!g->running)return;
    switch(g->screen) {
    case YScreenWorld:
        if(key<=YRight)do_step(g,key);
        else if(key==YOk)interact(g);
        else if(key==YBack){g->screen=YScreenMenu;g->selected=0;}
        break;
    case YScreenDialog:
        if(key==YOk||key==YBack) {
            if(++g->dialog_page>=g->dialog_count)resolve_pending(g);
        }
        break;
    case YScreenOakEncounter:
        if(key==YOk)open_dialog(g,capture_text,3,YPendingEnterLab);
        break;
    case YScreenRivalBattle:
        if(key==YOk){g->selected=0;g->screen=YScreenFightMenu;}
        break;
    case YScreenFightMenu:
        if(key==YUp&&g->selected)g->selected--;
        else if(key==YDown&&g->selected<2)g->selected++;
        else if(key==YBack)g->screen=YScreenRivalBattle;
        else if(key==YOk)battle_move(g);
        break;
    case YScreenMenu:
        if(key==YUp&&g->selected)g->selected--;
        else if(key==YDown&&g->selected<3)g->selected++;
        else if(key==YBack)g->screen=YScreenWorld;
        else if(key==YOk) {
            if(g->selected==0)g->screen=YScreenParty;
            else if(g->selected==1)g->screen=YScreenBag;
            else if(g->selected==2){g->request_save=true;g->message_saved=false;}
            else g->running=false;
        }
        break;
    case YScreenParty:case YScreenBag:
        if(key==YOk||key==YBack){
            uint8_t selected=(g->screen==YScreenParty)?0:1;
            g->screen=YScreenMenu;g->selected=selected;
        }
        break;
    }
}
static uint32_t checksum(const YellowSave* s) {
    /* Explicit serialization-independent checksum, no uninitialized padding. */
    uint32_t c=0xA54C537Bu;
    c^=s->magic^((uint32_t)s->version<<16);
    c^=(uint32_t)s->map<<24 ^ (uint32_t)s->x<<16 ^ (uint32_t)s->y<<8 ^ s->facing;
    c^=(uint32_t)s->hp<<24 ^ (uint32_t)s->potions<<16 ^ (uint32_t)s->story<<8 ^ s->has_pikachu;
    c^=(uint32_t)s->affection<<24 ^ (uint32_t)s->foe_hp<<16 ^ s->steps;
    c^=(uint32_t)s->follower_map<<24 ^ (uint32_t)s->follower_x<<16 ^
       (uint32_t)s->follower_y<<8 ^ s->follower_valid;
    return c^s->rng;
}
void yellow_save_create(const YellowGame* g,YellowSave* s) {
    memset(s,0,sizeof(*s));
    s->magic=YELLOW_SAVE_MAGIC;s->version=3;
    s->map=g->map;s->x=(uint8_t)g->x;s->y=(uint8_t)g->y;
    s->facing=g->facing;s->hp=g->hp;s->potions=g->potions;
    s->story=(uint8_t)g->story;s->has_pikachu=g->has_pikachu;s->affection=g->affection;
    s->foe_hp=g->foe_hp;s->follower_map=g->follower_map;
    s->follower_x=g->follower_x;s->follower_y=g->follower_y;
    s->follower_valid=g->follower_valid;s->steps=g->steps;s->rng=g->rng;
    s->checksum=checksum(s);
}
bool yellow_save_load(YellowGame* g,const YellowSave* s) {
    if(s->magic!=YELLOW_SAVE_MAGIC||s->version!=3||
       s->map>=YELLOW_MAP_COUNT||s->x>=yellow_map_w(s->map)||
       s->y>=yellow_map_h(s->map)||s->facing>YRight||
       s->hp==0||s->hp>YELLOW_MAX_HP||
       s->story>YStoryPikachuFollows||
       (s->story==YStoryPikachuFollows&&!s->has_pikachu)||
       (s->has_pikachu&&s->story<YStoryRivalBattle)||
       (s->follower_valid&&(s->follower_map>=YELLOW_MAP_COUNT||
           s->follower_x>=yellow_map_w(s->follower_map)||
           s->follower_y>=yellow_map_h(s->follower_map)))||
       s->checksum!=checksum(s))return false;
    YellowGame tmp={0};tmp.map=s->map;tmp.story=(YellowStory)s->story;
    if(!yellow_walkable(&tmp,s->x,s->y))return false;

    yellow_init(g);
    g->map=s->map;g->x=(int8_t)s->x;g->y=(int8_t)s->y;g->facing=s->facing;
    g->hp=s->hp;g->potions=s->potions;g->steps=s->steps;
    g->story=(YellowStory)s->story;g->has_pikachu=s->has_pikachu;
    g->affection=s->affection;g->foe_hp=s->foe_hp;g->rng=s->rng;
    g->screen=YScreenWorld;g->pending=YPendingNone;
    set_follower_near(g); /* rebuild follower, do not trust saved stale coordinates */
    return true;
}
