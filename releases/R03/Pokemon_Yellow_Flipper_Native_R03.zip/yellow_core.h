#ifndef YELLOW_CORE_H
#define YELLOW_CORE_H
#include <stdbool.h>
#include <stdint.h>

#define YELLOW_MAP_COUNT 4
#define YELLOW_SAVE_MAGIC 0x59464C50u
#define YELLOW_MAX_HP 19u
#define YELLOW_RIVAL_MAX_HP 21u

typedef enum {
    YScreenWorld, YScreenDialog, YScreenMenu, YScreenParty, YScreenBag,
    YScreenOakEncounter, YScreenRivalBattle, YScreenFightMenu
} YellowScreen;
typedef enum {YUp,YDown,YLeft,YRight,YOk,YBack} YellowKey;
typedef enum {YMapPallet,YMapRedsHouse,YMapBluesHouse,YMapOaksLab} YellowMap;
typedef enum {
    YActorRed,YActorOak,YActorGirl,YActorFisher,
    YActorBlue,YActorPikachu,YActorMom,YActorDaisy,
    YActorPokedex,YActorPokeBall,YActorScientist
} YellowActorType;
typedef enum {
    YStoryBeforeOak, YStoryOakEncounter,
    YStoryChooseStarter, YStoryRivalBattle, YStoryPikachuFollows
} YellowStory;
typedef enum {
    YPendingNone, YPendingBeginCapture, YPendingEnterLab,
    YPendingStartBattle, YPendingBeginRivalBattle, YPendingEndBattle
} YellowPending;
typedef struct {
    uint8_t map,x,y,type,dialog_id;
} YellowNpc;

/* New versioned save; older v0.2 save file remains untouched. */
typedef struct {
    uint32_t magic;
    uint16_t version;
    uint8_t map,x,y,facing,hp,potions;
    uint8_t story,has_pikachu,affection,foe_hp;
    uint8_t follower_map,follower_x,follower_y,follower_valid;
    uint16_t steps;
    uint32_t rng;
    uint32_t checksum;
} YellowSave;

typedef struct {
    int8_t x,y;
    uint8_t map,facing,hp,potions;
    uint16_t steps;
    uint8_t selected;
    uint8_t dialog_page,dialog_count;
    const char* const* dialog_lines;
    YellowScreen screen;
    bool running,request_save,message_saved;
    YellowStory story;
    YellowPending pending;
    uint8_t has_pikachu,affection,foe_hp,foe_attack_debuff;
    uint8_t follower_map,follower_x,follower_y,follower_valid;
    uint32_t rng;
} YellowGame;
extern const YellowNpc yellow_npcs[];
extern const uint8_t yellow_npc_count;

void yellow_init(YellowGame* g);
void yellow_input(YellowGame* g,YellowKey key);
bool yellow_walkable(const YellowGame* g,int x,int y);
uint8_t yellow_tile_id(uint8_t map,int tile_x,int tile_y);
int yellow_map_w(uint8_t map);
int yellow_map_h(uint8_t map);
bool yellow_npc_visible(const YellowGame* g,const YellowNpc* npc);
void yellow_save_create(const YellowGame* g,YellowSave* save);
bool yellow_save_load(YellowGame* g,const YellowSave* save);
#endif
